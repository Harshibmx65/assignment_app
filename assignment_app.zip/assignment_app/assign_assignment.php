<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: login.php?role=teacher");
    exit();
}

include 'db.php';

$teacher_id = $_SESSION['user_id'];

// Fetch subjects assigned to the teacher
$subjects_sql = "SELECT s.id, s.name FROM subjects s
                 JOIN teacher_subjects ts ON s.id = ts.subject_id
                 WHERE ts.teacher_id = ?";
$subjects_stmt = $conn->prepare($subjects_sql);
$subjects_stmt->bind_param("i", $teacher_id);
$subjects_stmt->execute();
$subjects_result = $subjects_stmt->get_result();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $subject_id = $_POST['subject_id'];
    $deadline = $_POST['deadline'];

    $insert_sql = "INSERT INTO assignments (title, subject_id, created_by, deadline) 
                   VALUES (?, ?, ?, ?)";
    $insert_stmt = $conn->prepare($insert_sql);
    $insert_stmt->bind_param("siis", $title, $subject_id, $teacher_id, $deadline);
    $insert_stmt->execute();
    $insert_stmt->close();

    header("Location: teacher_dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Assignment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('background.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', sans-serif;
        }
        .box {
            background: rgba(255, 240, 245, 0.95); /* baby soft pink */
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        h2 {
            color: #d63384;
            font-weight: bold;
        }
        .container {
            margin-top: 60px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2 class="text-center mb-4">Create New Assignment</h2>

    <div class="box">
        <form method="POST">
            <div class="mb-3">
                <label for="title" class="form-label">Assignment Title</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>

            <div class="mb-3">
                <label for="subject_id" class="form-label">Select Subject</label>
                <select class="form-control" id="subject_id" name="subject_id" required>
                    <?php while ($row = $subjects_result->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['name']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="deadline" class="form-label">Deadline</label>
                <input type="date" class="form-control" id="deadline" name="deadline" required>
            </div>

            <button type="submit" class="btn btn-success">Create Assignment</button>
        </form>
    </div>
</div>
</body>
</html>

<?php
$subjects_stmt->close();
$conn->close();
?>
