<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = isset($_POST['student_id']) ? (int)$_POST['student_id'] : 0;
    $assignment_id = isset($_POST['assignment_id']) ? (int)$_POST['assignment_id'] : 0;
    $marks = isset($_POST['marks']) ? (float)$_POST['marks'] : null;

    if ($student_id && $assignment_id && $marks !== null) {
        $update_sql = "UPDATE submissions SET marks = ? WHERE student_id = ? AND assignment_id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("dii", $marks, $student_id, $assignment_id);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo "Marks updated successfully!";
        } else {
            echo "No matching submission found or marks unchanged.";
        }

        $stmt->close();
    } else {
        echo "Invalid input. Please provide student_id, assignment_id, and marks.";
    }
}

$conn->close();
?>
