<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php?role=student");
    exit();
}

include 'db.php';
$student_id = $_SESSION['user_id'];

// Fetch student's subjects
$subject_query = "SELECT subject_id FROM student_subjects WHERE student_id = ?";
$stmt1 = $conn->prepare($subject_query);
$stmt1->bind_param("i", $student_id);
$stmt1->execute();
$subject_result = $stmt1->get_result();

$subjects = [];
while ($row = $subject_result->fetch_assoc()) {
    $subjects[] = $row['subject_id'];
}
$stmt1->close();

if (count($subjects) > 0) {
    $in_clause = implode(',', array_fill(0, count($subjects), '?'));
    $types = str_repeat('i', count($subjects)); // Adjusted to 'i' for subject_id

    // SQL query to fetch assignments for student's subjects along with submission details
    $sql = "SELECT a.title, a.due_date, s.submission_date, s.marks
            FROM assignments a
            LEFT JOIN submissions s ON a.id = s.assignment_id AND s.student_id = ?
            WHERE a.subject_id IN ($in_clause)";
    
    $stmt2 = $conn->prepare($sql);
    $params = array_merge([$student_id], $subjects);
    $stmt2->bind_param("i" . $types, ...$params);
    $stmt2->execute();
    $result = $stmt2->get_result();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container mt-4">
        <h1>Welcome, Student</h1>
        <a href="logout.php" class="btn btn-danger mt-3">Logout</a>
        <h3 class="mt-5">Your Assignments</h3>
        <?php if (isset($result)) : ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Assignment Title</th>
                    <th>Due Date</th>
                    <th>Submission Date</th>
                    <th>Marks</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                    <td><?php echo htmlspecialchars($row['due_date']); ?></td>
                    <td><?php echo $row['submission_date'] ? htmlspecialchars($row['submission_date']) : 'Not Submitted'; ?></td>
                    <td><?php echo $row['marks'] !== null ? htmlspecialchars($row['marks']) : 'Not Graded'; ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else : ?>
            <p>No assignments found for your subjects.</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
if (isset($stmt2)) $stmt2->close();
$conn->close();
?>
