<?php
session_start();

// Ensure the student is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php?role=student");
    exit();
}

include 'db.php';
$student_id = $_SESSION['user_id'];

// Get student's subjects
$subject_sql = "SELECT subject_id FROM student_subjects WHERE student_id = ?";
$subject_stmt = $conn->prepare($subject_sql);
$subject_stmt->bind_param("i", $student_id);
$subject_stmt->execute();
$subject_result = $subject_stmt->get_result();

$subjects = [];
while ($row = $subject_result->fetch_assoc()) {
    $subjects[] = $row['subject_id'];
}

$dues_result = null;
if (!empty($subjects)) {
    $subject_placeholders = implode(',', array_fill(0, count($subjects), '?'));

    // Fetch due assignments (assignments not submitted yet)
    $dues_sql = "
        SELECT a.id, a.title, s.name AS subject_name
        FROM assignments a
        JOIN subjects s ON a.subject_id = s.id
        WHERE a.subject_id IN ($subject_placeholders)
        AND NOT EXISTS (
            SELECT 1 FROM submissions sub
            WHERE sub.assignment_id = a.id AND sub.student_id = ?
        )
    ";
    $dues_stmt = $conn->prepare($dues_sql);
    $params = array_merge($subjects, [$student_id]);
    $dues_stmt->bind_param(str_repeat('i', count($subjects)) . 'i', ...$params);
    $dues_stmt->execute();
    $dues_result = $dues_stmt->get_result();
}

// Fetch submitted assignments with marks
$submitted_sql = "
    SELECT a.title, s.submission_date, s.marks
    FROM submissions s
    JOIN assignments a ON s.assignment_id = a.id
    WHERE s.student_id = ?
";
$submitted_stmt = $conn->prepare($submitted_sql);
$submitted_stmt->bind_param("i", $student_id);
$submitted_stmt->execute();
$submitted_result = $submitted_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('background.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', sans-serif;
        }
        .box {
            background: rgba(255, 240, 245, 0.95);
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        h2, h4 {
            color: #d63384;
            font-weight: bold;
        }
        .list-group-item {
            background-color: #ffe6f0;
            border: none;
        }
        table thead {
            background-color: #f8d7da;
            color: #721c24;
        }
        .container {
            margin-top: 60px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2 class="text-center mb-4">Welcome, Student</h2>

    <!-- DUE ASSIGNMENTS -->
    <div class="box">
        <h4>Your Assignment Dues</h4>
        <?php if ($dues_result && $dues_result->num_rows > 0): ?>
            <ul class="list-group">
                <?php while ($row = $dues_result->fetch_assoc()): ?>
                    <li class="list-group-item">
                        <strong><?php echo htmlspecialchars($row['title']); ?></strong><br>
                        Subject: <?php echo htmlspecialchars($row['subject_name']); ?><br>
                        <form action="submit_assignment.php" method="POST" enctype="multipart/form-data" class="mt-2">
                            <input type="hidden" name="assignment_id" value="<?php echo $row['id']; ?>">
                            <input type="file" name="file" class="form-control mb-2" accept=".doc,.docx,.pdf">
                            <input type="text" name="offline_note" class="form-control mb-2" placeholder="Or write: submitted offline">
                            <button type="submit" class="btn btn-primary btn-sm">Submit</button>
                        </form>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>No pending assignments!</p>
        <?php endif; ?>
    </div>

    <!-- SUBMITTED ASSIGNMENTS -->
    <div class="box">
        <h4>Your Submitted Assignments and Marks</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Assignment Title</th>
                    <th>Submission Date</th>
                    <th>Marks</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $submitted_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars($row['submission_date']); ?></td>
                        <td><?php echo $row['marks'] !== null ? htmlspecialchars($row['marks']) : 'Not Graded'; ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>

<?php
if (isset($dues_stmt)) $dues_stmt->close();
$submitted_stmt->close();
$conn->close();
?>
