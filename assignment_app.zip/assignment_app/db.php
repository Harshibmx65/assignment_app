<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "assignment_app";

// Create connection
$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the character set to UTF-8 for proper encoding
$conn->set_charset("utf8");

// Additional database setup or query handling can be done here if needed

?>
