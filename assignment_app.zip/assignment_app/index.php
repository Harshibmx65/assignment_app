<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Assignment Manager</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h1>📚 Assignment Management System</h1>
    <p>Select your role:</p>
    <div class="button-group">
      <a href="login.php?role=student" class="btn">Student Login</a>
      <a href="login.php?role=teacher" class="btn">Teacher Login</a>
    </div>
    <p class="mt-3">New to the system? 
      <a href="register_student.php" class="btn register-btn">Register as a Student</a>
    </p>
    <p>Teachers, you will be able to log in here, and you should already have a registered account with your email and password.</p>
  </div>
</body>
</html>
