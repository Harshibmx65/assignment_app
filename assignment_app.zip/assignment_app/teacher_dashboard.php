<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?role=teacher");
    exit();
}

include 'db.php';

$teacher_id = $_SESSION['user_id'];

// Fetch assignments created by the teacher
$assignments_sql = "SELECT a.id, a.title, s.name AS subject_name
                    FROM assignments a
                    JOIN subjects s ON s.id = a.subject_id
                    WHERE a.created_by = ?";
$assignments_stmt = $conn->prepare($assignments_sql);
$assignments_stmt->bind_param("i", $teacher_id);
$assignments_stmt->execute();
$assignments_result = $assignments_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Teacher Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('background.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', sans-serif;
        }
        .box {
            background: rgba(255, 240, 245, 0.95); /* baby soft pink */
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        h2, h4 {
            color: #d63384;
            font-weight: bold;
        }
        .list-group-item {
            background-color: #ffe6f0;
            border: none;
        }
        table thead {
            background-color: #f8d7da;
            color: #721c24;
        }
        .container {
            margin-top: 60px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2 class="text-center mb-4">Welcome, Teacher</h2>

    <div class="box">
        <h4>Your Assignments</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Assignment Title</th>
                    <th>Subject</th>
                    <th>Manage Submissions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $assignments_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                        <td>
                            <a href="view_submissions.php?assignment_id=<?php echo $row['id']; ?>" class="btn btn-primary">
                                View Submissions
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <div class="box">
        <h4>Create a New Assignment</h4>
        <a href="assign_assignment.php" class="btn btn-success">Create Assignment</a>
    </div>
</div>
</body>
</html>

<?php
$assignments_stmt->close();
$conn->close();
?>
