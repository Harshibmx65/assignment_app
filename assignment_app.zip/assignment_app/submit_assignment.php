<?php
session_start();

// Check if the user is logged in as a student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php?role=student");
    exit();
}

include 'db.php';

// Get the student ID from session and assignment ID from POST
$student_id = $_SESSION['user_id'];
$assignment_id = $_POST['assignment_id'];
$submission_date = date('Y-m-d');  // Current date
$marks = null;  // Marks are initially NULL as it will be updated by the teacher
$file_path = ''; // Path to the uploaded file
$offline_note = ''; // Note for offline submission

// Set the upload directory for files
$upload_dir = "uploads/";

// Handle file upload
if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
    $file_tmp = $_FILES['file']['tmp_name'];
    $file_name = basename($_FILES['file']['name']);
    $target_path = $upload_dir . time() . "_" . $file_name;  // Create a unique filename using timestamp

    // Create uploads directory if it doesn't exist
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true); // Make uploads directory if not already present
    }

    // Move the uploaded file to the target path
    if (move_uploaded_file($file_tmp, $target_path)) {
        $file_path = $target_path; // Set the file path if upload is successful
    } else {
        die("File upload failed.");
    }
}

// Handle offline note (if provided)
if (isset($_POST['offline_note']) && !empty(trim($_POST['offline_note']))) {
    $offline_note = trim($_POST['offline_note']);
}

// Validation: at least one of the file or note must be provided for the submission
if (empty($file_path) && empty($offline_note)) {
    die("Please upload a file or add a note for offline submission.");
}

// Prepare and execute the SQL query to save the submission in the database
$submission_sql = "INSERT INTO submissions (student_id, assignment_id, submission_date, file_path, marks, offline_note)
                   VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($submission_sql);

// Bind parameters (i = integer, s = string)
$stmt->bind_param("iissss", $student_id, $assignment_id, $submission_date, $file_path, $marks, $offline_note);

if ($stmt->execute()) {
    // If submission is successful, redirect to the student dashboard with success flag
    header("Location: student_dashboard.php?success=1");
    exit();
} else {
    // If there's an error while submitting, show an error message
    echo "Error submitting assignment. Please try again later.";
}

// Close the prepared statement and database connection
$stmt->close();
$conn->close();
?>
