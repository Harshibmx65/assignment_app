<?php
include 'db.php';

// Start session to manage teacher login
session_start();

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get input values
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Use prepared statement to avoid SQL injection
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND role = 'teacher'");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if any row is returned
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();

        // Check if password matches using password_verify for hashed passwords
        if (password_verify($password, $row['password'])) {
            // Store teacher ID in session
            $_SESSION['teacher_id'] = $row['id'];
            
            // Redirect to the teacher dashboard
            header("Location: teacher_dashboard.php");
            exit();
        } else {
            // Invalid password
            echo "Login failed! Incorrect password.";
        }
    } else {
        // No matching teacher found
        echo "Login failed! Teacher not found.";
    }
    
    // Close statement
    $stmt->close();
}

// Close database connection
$conn->close();
?>

<!-- Teacher Login Form (HTML) -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Teacher Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="bg-light">
    <div class="container mt-4">
        <h1>Teacher Login</h1>
        <form method="POST" action="teacher.php">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary mt-3">Login</button>
        </form>
    </div>
</body>
</html>
