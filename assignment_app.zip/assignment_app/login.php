<?php
session_start();
$role = $_GET['role'] ?? '';

if (!in_array($role, ['student', 'teacher'])) {
    die("Invalid role selected.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo ucfirst($role); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('background.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            font-family: Arial, sans-serif;
        }
        .login-container {
            background-color: #f5e6e8;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            margin: 50px auto;
        }
        .login-container h2 {
            font-size: 28px;
            margin-bottom: 30px;
            color: #2c3e50;
        }
        .form-control {
            border-radius: 8px;
            border: 1px solid #ddd;
            padding: 12px;
            font-size: 14px;
        }
        .btn-primary {
            background-color: #3498db;
            border-color: #3498db;
            width: 100%;
            padding: 12px;
            border-radius: 8px;
        }
        .btn-primary:hover {
            background-color: #2980b9;
            border-color: #2980b9;
        }
        .error-message {
            color: #e74c3c;
            font-size: 14px;
            margin-top: 10px;
        }
    </style>
</head>
<body class="bg-light">

<div class="login-container">
    <h2><?php echo ucfirst($role); ?> Login</h2>
    <form method="post" action="login.php?role=<?php echo $role; ?>" class="mt-4">
        <div class="form-group mb-3">
            <input type="email" name="email" placeholder="Email" required class="form-control">
        </div>
        <div class="form-group mb-3">
            <input type="password" name="password" placeholder="Password" required class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Login</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        include 'db.php';

        $email = $_POST['email'];
        $password = trim($_POST['password']); // Trim whitespace

        // Determine table name
        $table = ($role === 'student') ? 'students' : 'teachers';

        $stmt = $conn->prepare("SELECT id, password FROM $table WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows === 1) {
            $user = $result->fetch_assoc();

            // Plain-text password comparison
            if ($password === $user['password']) {
                session_regenerate_id(true);
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = $role;

                header("Location: " . $role . "_dashboard.php");
                exit;
            } else {
                echo "<p class='error-message'>Incorrect password.</p>";
            }
        } else {
            echo "<p class='error-message'>No user found with this email.</p>";
        }

        $stmt->close();
        $conn->close();
    }
    ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
