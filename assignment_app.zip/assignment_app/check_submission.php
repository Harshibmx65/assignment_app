<?php
include 'db.php';

$student_id = $_POST['student_id'];
$assignment_id = $_POST['assignment_id'];
$teacher_id = $_POST['teacher_id'];

// Fetch submission for that assignment and student only if assigned by this teacher
$sql = "SELECT s.*, a.title
        FROM submissions s
        JOIN assignments a ON s.assignment_id = a.id
        WHERE s.student_id = ? AND s.assignment_id = ? AND a.teacher_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iii", $student_id, $assignment_id, $teacher_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "Assignment: " . htmlspecialchars($row["title"]) . "<br>";
    echo "Submission Date: " . $row["submission_date"] . "<br>";
    echo "Marks: " . $row["marks"] . "<br>";
} else {
    echo "No submission found for the given assignment under your subject.";
}

$stmt->close();
$conn->close();
?>
