<?php
// Start the session
session_start();

// Check if a user is logged in
if (isset($_SESSION['user_id'])) {
    // Include database connection
    include 'db.php';

    // Assuming there's a column `is_logged_in` in the users table that tracks login status
    $user_id = $_SESSION['user_id'];

    // Update the user's status to logged out in the database (optional)
    $update_sql = "UPDATE users SET is_logged_in = 0 WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->close();
}

// Destroy all session data
session_destroy();

// Redirect the user to the login page
header('Location: login.php');
exit();
?>
