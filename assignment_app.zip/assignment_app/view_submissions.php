<?php 
include 'db.php';

$teacher_id = $_POST['teacher_id'];

// Get all submissions for assignments created by this teacher
$sql = "SELECT 
            students.name AS student_name, 
            assignments.title AS assignment_title, 
            submissions.marks, 
            submissions.submission_date
        FROM submissions
        JOIN students ON submissions.student_id = students.id
        JOIN assignments ON submissions.assignment_id = assignments.id
        WHERE assignments.created_by = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "Student Name: " . htmlspecialchars($row["student_name"]) . "<br>";
        echo "Assignment: " . htmlspecialchars($row["assignment_title"]) . "<br>";
        echo "Marks: " . $row["marks"] . "<br>";
        echo "Submission Date: " . $row["submission_date"] . "<br><br>";
    }
} else {
    echo "No submissions found for your assignments.";
}

$stmt->close();
$conn->close();
?>
