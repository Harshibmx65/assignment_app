<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>

<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize form data
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $usn = mysqli_real_escape_string($conn, $_POST['usn']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $sem = mysqli_real_escape_string($conn, $_POST['sem']);
    $section = mysqli_real_escape_string($conn, $_POST['section']);
    $subjects = $_POST['subjects']; // array of subject_ids

    // Insert into students table using prepared statements (without phone)
    $stmt = $conn->prepare("INSERT INTO students (usn, name, email, password, sem, section) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $usn, $name, $email, $password, $sem, $section);
    $stmt->execute();
    $student_id = $stmt->insert_id;  // Get the student ID after insertion
    $stmt->close();

    // Insert subjects for this student using prepared statements
    if (isset($subjects) && !empty($subjects)) {
        $stmt_subject = $conn->prepare("INSERT INTO student_subjects (student_id, subject_id) VALUES (?, ?)");
        foreach ($subjects as $subject_id) {
            // Ensure subject_id is valid
            $stmt_subject->bind_param("ii", $student_id, $subject_id);  // Bind student_id and subject_id
            $stmt_subject->execute();
        }
        $stmt_subject->close();
    }

    echo "Registration successful! <a href='index.php'>Login here</a>";
    exit;
}

// Fetch subjects from the database
$subject_result = $conn->query("SELECT id, name FROM subjects");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Student Registration</h1>
    <form method="POST" action="">
        <input type="text" name="name" placeholder="Full Name" required><br><br>
        <input type="text" name="usn" placeholder="USN" required><br><br>
        <input type="email" name="email" placeholder="Email" required><br><br>
        <input type="password" name="password" placeholder="Password" required><br><br>
        <input type="text" name="sem" placeholder="Semester" required><br><br>
        <input type="text" name="section" placeholder="Section" required><br><br>

        <label>Select Subjects:</label><br>
        <?php while($row = $subject_result->fetch_assoc()): ?>
            <input type="checkbox" name="subjects[]" value="<?= $row['id'] ?>"> <?= $row['name'] ?><br>
        <?php endwhile; ?><br>

        <input class="btn" type="submit" value="Register">
    </form>
</div>
</body>
</html>
